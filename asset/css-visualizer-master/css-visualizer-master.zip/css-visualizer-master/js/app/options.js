define([], function() {

    var Options = {
        debug: false,
        debugVolume: 0.5,

        defaultVolume: 0.2,
        autoplayRandom: true,
        hideVis: false,
        fadeUI: true
    };

    return Options;
});
